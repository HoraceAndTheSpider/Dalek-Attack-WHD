#!/usr/bin/env python3
"""
Dalek Attack (Amiga) playable-character sprite-sheet round-trip tool.

One character animation bank:
    45 frames
    32 x 40 pixels per frame
    4 bitplanes / 16 colours
    640 bytes per frame
    28,800 bytes total ($7080)

Editable sprite sheet:
    9 columns x 5 rows
    288 x 200 pixels
    frame order is left-to-right, top-to-bottom: 0..44

IMPORTANT:
    Palette index 0 is still the game's transparent/background index.
    For EDITING ONLY it is displayed as Amiga $F0F / RGB #FF00FF magenta.
    Import converts by palette INDEX, so index 0 remains index 0 in the
    reconstructed game bank. No magenta colour is added to the game data.

Commands:
    export BANK.bin OUTBASE [--format png|ilbm|both]
    import SHEET.png OUT.bin
    import SHEET.iff OUT.bin
    verify BANK.bin WORKDIR

Optional 32x32 selection portrait:
    portrait-export PORTRAIT.bin OUTBASE [--format png|ilbm|both]
    portrait-import PORTRAIT.png OUT.bin
    portrait-import PORTRAIT.iff OUT.bin

Complete character set:
    set-export BANK.bin PORTRAIT.bin OUTDIR [--format png|ilbm|both]
    set-import INDIR BANK_OUT.bin PORTRAIT_OUT.bin [--format auto|png|ilbm]
    set-verify BANK.bin PORTRAIT.bin WORKDIR

The tool has NO fixed input directory. Every path is supplied on the command
line. Relative paths are relative to the directory you run the command from.
"""

from __future__ import annotations
import argparse
import hashlib
import struct
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("error: Pillow is required. Install with: python3 -m pip install pillow",
          file=sys.stderr)
    raise SystemExit(2)

FRAME_W = 32
FRAME_H = 40
FRAMES = 45
SHEET_COLS = 9
SHEET_ROWS = 5
SHEET_W = FRAME_W * SHEET_COLS
SHEET_H = FRAME_H * SHEET_ROWS
PLANES = 4
FRAME_BYTES = (FRAME_W // 8) * PLANES * FRAME_H
BANK_BYTES = FRAME_BYTES * FRAMES

PORTRAIT_W = 32
PORTRAIT_H = 32
PORTRAIT_BYTES = (PORTRAIT_W // 8) * PLANES * PORTRAIT_H

# Main game/playfield palette recovered from runtime $11E74.
# Actual game COLOR00 is black. For the EDITOR palette only, index 0 is
# deliberately shown as $F0F magenta so transparent/background pixels
# remain obvious while editing.
AMIGA12_PLAYFIELD = [
    0x000, 0x039, 0x666, 0x888, 0x642, 0x864, 0xA86, 0x264,
    0xCA4, 0x26C, 0x112, 0x488, 0x444, 0xA22, 0x000, 0xEEE,
]

def amiga12_rgb(c: int):
    return (((c >> 8) & 0xF) * 17, ((c >> 4) & 0xF) * 17, (c & 0xF) * 17)

GAME_RGB = [amiga12_rgb(c) for c in AMIGA12_PLAYFIELD]
EDITOR_RGB = GAME_RGB.copy()
EDITOR_RGB[0] = (255, 0, 255)  # Amiga $F0F

def pil_palette(rgb):
    flat = []
    for c in rgb:
        flat.extend(c)
    return flat + [0] * (768 - len(flat))

EDITOR_PAL = pil_palette(EDITOR_RGB)

def load_exact(path: Path, size: int, label: str) -> bytes:
    raw = path.read_bytes()
    if len(raw) != size:
        raise ValueError(f"{label} must be exactly {size} bytes, got {len(raw)}: {path}")
    return raw

def encode_indices(indices, width: int, height: int) -> bytes:
    if len(indices) != width * height:
        raise ValueError("wrong pixel count")
    if width % 16:
        raise ValueError("width must be a multiple of 16")
    row_bytes = width // 8
    out = bytearray()
    for y in range(height):
        row = indices[y * width:(y + 1) * width]
        for plane in range(PLANES):
            for xb in range(row_bytes):
                v = 0
                for bitpos in range(8):
                    x = xb * 8 + bitpos
                    v |= ((row[x] >> plane) & 1) << (7 - bitpos)
                out.append(v)
    return bytes(out)

def decode_planar(raw: bytes, width: int, height: int) -> list[int]:
    if width % 16:
        raise ValueError("width must be a multiple of 16")
    row_bytes = width // 8
    expected = row_bytes * PLANES * height
    if len(raw) != expected:
        raise ValueError(f"planar data must be {expected} bytes, got {len(raw)}")
    indices = [0] * (width * height)
    off = 0
    for y in range(height):
        planes = [raw[off + p * row_bytes:off + (p + 1) * row_bytes]
                  for p in range(PLANES)]
        off += row_bytes * PLANES
        for x in range(width):
            bi = x >> 3
            bit = 7 - (x & 7)
            v = 0
            for p in range(PLANES):
                v |= ((planes[p][bi] >> bit) & 1) << p
            indices[y * width + x] = v
    return indices

def indexed_image(indices, width: int, height: int):
    im = Image.new("P", (width, height), 0)
    im.putpalette(EDITOR_PAL)
    im.putdata(indices)
    # Deliberately DO NOT set PNG transparency.
    # Index 0 must be visibly magenta while editing.
    return im

def image_to_indices(im: Image.Image, width: int, height: int) -> list[int]:
    if im.size != (width, height):
        raise ValueError(f"image must be {width}x{height}, got {im.size}")

    if im.mode == "P":
        vals = list(im.getdata())
        if any(v > 15 for v in vals):
            raise ValueError("indexed image contains palette index > 15")

        pal = im.getpalette()
        if pal:
            # Require colours 1..15 to remain exact. Index 0 may be the
            # editor magenta or the real game black.
            got = [tuple(pal[i*3:i*3+3]) for i in range(16)]
            if got[1:16] != EDITOR_RGB[1:16]:
                raise ValueError(
                    "palette entries 1..15 differ from the Dalek Attack playfield palette; "
                    "keep the image indexed and do not optimise/reorder its palette"
                )
            if got[0] not in (EDITOR_RGB[0], GAME_RGB[0]):
                raise ValueError(
                    "palette index 0 must remain editor magenta #FF00FF or game black #000000"
                )
        return vals

    # RGB/RGBA import is allowed, but only exact known editor colours.
    # This is intentionally strict: no nearest-colour conversion.
    rgba = im.convert("RGBA")
    cmap = {(*rgb, 255): i for i, rgb in enumerate(EDITOR_RGB)}
    # Actual black index 0 is ambiguous with game palette index 14.
    # In the editor palette, black uniquely means index 14; magenta means 0.
    vals = []
    for px in rgba.getdata():
        if px[3] == 0:
            vals.append(0)
            continue
        key = (px[0], px[1], px[2], 255)
        if key not in cmap:
            raise ValueError(
                f"RGB colour {px[:3]} is not an exact Dalek Attack editor-palette colour"
            )
        vals.append(cmap[key])
    return vals

def bank_to_sheet_indices(bank: bytes) -> list[int]:
    if len(bank) != BANK_BYTES:
        raise ValueError(f"bank must be {BANK_BYTES} bytes")
    sheet = [0] * (SHEET_W * SHEET_H)
    for f in range(FRAMES):
        frame_raw = bank[f*FRAME_BYTES:(f+1)*FRAME_BYTES]
        frame = decode_planar(frame_raw, FRAME_W, FRAME_H)
        fx = (f % SHEET_COLS) * FRAME_W
        fy = (f // SHEET_COLS) * FRAME_H
        for y in range(FRAME_H):
            src = y * FRAME_W
            dst = (fy + y) * SHEET_W + fx
            sheet[dst:dst+FRAME_W] = frame[src:src+FRAME_W]
    return sheet

def sheet_indices_to_bank(sheet: list[int]) -> bytes:
    if len(sheet) != SHEET_W * SHEET_H:
        raise ValueError("bad sheet pixel count")
    out = bytearray()
    for f in range(FRAMES):
        fx = (f % SHEET_COLS) * FRAME_W
        fy = (f // SHEET_COLS) * FRAME_H
        frame = []
        for y in range(FRAME_H):
            src = (fy + y) * SHEET_W + fx
            frame.extend(sheet[src:src+FRAME_W])
        out.extend(encode_indices(frame, FRAME_W, FRAME_H))
    if len(out) != BANK_BYTES:
        raise AssertionError(len(out))
    return bytes(out)

def _chunk(tag: bytes, data: bytes) -> bytes:
    return tag + struct.pack(">I", len(data)) + data + (b"\0" if len(data) & 1 else b"")

def write_ilbm_indices(indices, path: Path, width: int, height: int):
    raw = encode_indices(indices, width, height)
    # masking=0: keep index 0 visibly magenta in normal ILBM viewers/editors.
    bmhd = struct.pack(">HHhhBBBBHBBhh",
                       width, height, 0, 0, PLANES, 0, 0, 0, 0, 10, 11, width, height)
    cmap = bytes(v for rgb in EDITOR_RGB for v in rgb)
    payload = b"ILBM" + _chunk(b"BMHD", bmhd) + _chunk(b"CMAP", cmap) + _chunk(b"BODY", raw)
    path.write_bytes(b"FORM" + struct.pack(">I", len(payload)) + payload)

def byterun1_decode(data: bytes, expected: int) -> bytes:
    out = bytearray()
    i = 0
    while len(out) < expected:
        if i >= len(data):
            raise ValueError("truncated ByteRun1 BODY")
        n = struct.unpack("b", data[i:i+1])[0]
        i += 1
        if 0 <= n <= 127:
            count = n + 1
            if i + count > len(data):
                raise ValueError("truncated ByteRun1 literal")
            out.extend(data[i:i+count])
            i += count
        elif -127 <= n <= -1:
            count = 1 - n
            if i >= len(data):
                raise ValueError("truncated ByteRun1 repeat")
            out.extend(data[i:i+1] * count)
            i += 1
        else:
            pass
    if len(out) != expected:
        raise ValueError("ByteRun1 overrun")
    return bytes(out)

def read_ilbm_indices(path: Path, width: int, height: int) -> list[int]:
    b = path.read_bytes()
    if len(b) < 12 or b[:4] != b"FORM" or b[8:12] != b"ILBM":
        raise ValueError(f"{path}: not an ILBM")
    pos = 12
    chunks = {}
    end = min(len(b), 8 + int.from_bytes(b[4:8], "big"))
    while pos + 8 <= end:
        tag = b[pos:pos+4]
        n = int.from_bytes(b[pos+4:pos+8], "big")
        pos += 8
        chunks[tag] = b[pos:pos+n]
        pos += n + (n & 1)

    if b"BMHD" not in chunks or b"BODY" not in chunks:
        raise ValueError("ILBM missing BMHD/BODY")
    vals = struct.unpack(">HHhhBBBBHBBhh", chunks[b"BMHD"][:20])
    w, h, _, _, nplanes, masking, compression, _, _, _, _, _, _ = vals
    if (w, h, nplanes) != (width, height, PLANES):
        raise ValueError(f"ILBM must be {width}x{height}x{PLANES}, got {w}x{h}x{nplanes}")
    if masking not in (0, 2):
        raise ValueError("ILBM mask plane is not supported")

    rowbytes = ((w + 15) // 16) * 2
    expected = rowbytes * h * nplanes
    body = chunks[b"BODY"]
    if compression == 0:
        if len(body) < expected:
            raise ValueError("short ILBM BODY")
        body = body[:expected]
    elif compression == 1:
        body = byterun1_decode(body, expected)
    else:
        raise ValueError(f"unsupported ILBM compression {compression}")

    # All supported widths are multiples of 16, so ILBM row padding equals
    # our planar row size.
    return decode_planar(body, width, height)

def export_bank(bankpath: Path, outbase: Path, fmt: str):
    bank = load_exact(bankpath, BANK_BYTES, "character bank")
    indices = bank_to_sheet_indices(bank)
    outbase.parent.mkdir(parents=True, exist_ok=True)

    if fmt in ("png", "both"):
        p = outbase if outbase.suffix.lower() == ".png" else outbase.with_suffix(".png")
        indexed_image(indices, SHEET_W, SHEET_H).save(p)

    if fmt in ("ilbm", "both"):
        p = outbase if outbase.suffix.lower() in (".iff", ".ilbm") else outbase.with_suffix(".iff")
        write_ilbm_indices(indices, p, SHEET_W, SHEET_H)

def import_bank(inpath: Path, outpath: Path):
    ext = inpath.suffix.lower()
    if ext == ".png":
        indices = image_to_indices(Image.open(inpath), SHEET_W, SHEET_H)
    elif ext in (".iff", ".ilbm"):
        indices = read_ilbm_indices(inpath, SHEET_W, SHEET_H)
    else:
        raise ValueError("input must be .png, .iff or .ilbm")
    outpath.parent.mkdir(parents=True, exist_ok=True)
    outpath.write_bytes(sheet_indices_to_bank(indices))

def export_portrait(portraitpath: Path, outbase: Path, fmt: str):
    raw = load_exact(portraitpath, PORTRAIT_BYTES, "portrait")
    indices = decode_planar(raw, PORTRAIT_W, PORTRAIT_H)
    outbase.parent.mkdir(parents=True, exist_ok=True)

    if fmt in ("png", "both"):
        p = outbase if outbase.suffix.lower() == ".png" else outbase.with_suffix(".png")
        indexed_image(indices, PORTRAIT_W, PORTRAIT_H).save(p)

    if fmt in ("ilbm", "both"):
        p = outbase if outbase.suffix.lower() in (".iff", ".ilbm") else outbase.with_suffix(".iff")
        write_ilbm_indices(indices, p, PORTRAIT_W, PORTRAIT_H)

def import_portrait(inpath: Path, outpath: Path):
    ext = inpath.suffix.lower()
    if ext == ".png":
        indices = image_to_indices(Image.open(inpath), PORTRAIT_W, PORTRAIT_H)
    elif ext in (".iff", ".ilbm"):
        indices = read_ilbm_indices(inpath, PORTRAIT_W, PORTRAIT_H)
    else:
        raise ValueError("portrait input must be .png, .iff or .ilbm")
    outpath.parent.mkdir(parents=True, exist_ok=True)
    outpath.write_bytes(encode_indices(indices, PORTRAIT_W, PORTRAIT_H))

def export_set(bankpath: Path, portraitpath: Path, outdir: Path, fmt: str):
    outdir.mkdir(parents=True, exist_ok=True)
    export_bank(bankpath, outdir / "character", fmt)
    export_portrait(portraitpath, outdir / "portrait", fmt)
    (outdir / "README.txt").write_text(
        "Dalek Attack editable character set\n\n"
        "character.png / character.iff : 45 animation frames, 9x5 grid\n"
        "portrait.png / portrait.iff   : 32x32 menu portrait\n"
        "Palette index 0 is shown as #FF00FF / Amiga $F0F for editing.\n"
        "It still becomes transparent/background index 0 in the raw game data.\n",
        encoding="utf-8"
    )

def import_set(indir: Path, bankout: Path, portraitout: Path, fmt: str):
    if fmt == "auto":
        cp = indir / "character.png"
        ci = indir / "character.iff"
        pp = indir / "portrait.png"
        pi = indir / "portrait.iff"
        if cp.exists() and pp.exists():
            c, p = cp, pp
        elif ci.exists() and pi.exists():
            c, p = ci, pi
        else:
            raise ValueError(
                "need character.png + portrait.png, or character.iff + portrait.iff"
            )
    elif fmt == "png":
        c, p = indir / "character.png", indir / "portrait.png"
    else:
        c, p = indir / "character.iff", indir / "portrait.iff"

    import_bank(c, bankout)
    import_portrait(p, portraitout)

def verify_bank(bankpath: Path, workdir: Path):
    original = load_exact(bankpath, BANK_BYTES, "character bank")
    workdir.mkdir(parents=True, exist_ok=True)
    print("original", hashlib.sha256(original).hexdigest())
    for fmt, ext in (("png", ".png"), ("ilbm", ".iff")):
        base = workdir / f"character_{fmt}"
        export_bank(bankpath, base, fmt)
        rebuilt = workdir / f"roundtrip_{fmt}.bin"
        import_bank(base.with_suffix(ext), rebuilt)
        rb = rebuilt.read_bytes()
        print(fmt, "OK" if rb == original else "FAIL", hashlib.sha256(rb).hexdigest())
        if rb != original:
            raise SystemExit(1)

def verify_set(bankpath: Path, portraitpath: Path, workdir: Path):
    bank = load_exact(bankpath, BANK_BYTES, "character bank")
    portrait = load_exact(portraitpath, PORTRAIT_BYTES, "portrait")
    workdir.mkdir(parents=True, exist_ok=True)
    for fmt in ("png", "ilbm"):
        d = workdir / f"set_{fmt}"
        export_set(bankpath, portraitpath, d, fmt)
        bo = workdir / f"bank_roundtrip_{fmt}.bin"
        po = workdir / f"portrait_roundtrip_{fmt}.bin"
        import_set(d, bo, po, fmt)
        bok = bo.read_bytes() == bank
        pok = po.read_bytes() == portrait
        print(fmt, "bank", "OK" if bok else "FAIL",
              "portrait", "OK" if pok else "FAIL")
        if not (bok and pok):
            raise SystemExit(1)

def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("export", help="export one $7080 character bank as one 9x5 sprite sheet")
    p.add_argument("bank", type=Path)
    p.add_argument("outbase", type=Path)
    p.add_argument("--format", choices=["png", "ilbm", "both"], default="both")

    p = sp.add_parser("import", help="import one edited 9x5 sprite sheet back to a $7080 bank")
    p.add_argument("input", type=Path)
    p.add_argument("out", type=Path)

    p = sp.add_parser("verify", help="prove PNG and ILBM round-trip against one original bank")
    p.add_argument("bank", type=Path)
    p.add_argument("workdir", type=Path)

    p = sp.add_parser("portrait-export")
    p.add_argument("portrait", type=Path)
    p.add_argument("outbase", type=Path)
    p.add_argument("--format", choices=["png", "ilbm", "both"], default="both")

    p = sp.add_parser("portrait-import")
    p.add_argument("input", type=Path)
    p.add_argument("out", type=Path)

    p = sp.add_parser("set-export", help="export one character bank + its 32x32 portrait")
    p.add_argument("bank", type=Path)
    p.add_argument("portrait", type=Path)
    p.add_argument("outdir", type=Path)
    p.add_argument("--format", choices=["png", "ilbm", "both"], default="both")

    p = sp.add_parser("set-import", help="rebuild one character bank + portrait")
    p.add_argument("indir", type=Path)
    p.add_argument("bankout", type=Path)
    p.add_argument("portraitout", type=Path)
    p.add_argument("--format", choices=["auto", "png", "ilbm"], default="auto")

    p = sp.add_parser("set-verify")
    p.add_argument("bank", type=Path)
    p.add_argument("portrait", type=Path)
    p.add_argument("workdir", type=Path)

    a = ap.parse_args()
    try:
        if a.cmd == "export":
            export_bank(a.bank, a.outbase, a.format)
        elif a.cmd == "import":
            import_bank(a.input, a.out)
        elif a.cmd == "verify":
            verify_bank(a.bank, a.workdir)
        elif a.cmd == "portrait-export":
            export_portrait(a.portrait, a.outbase, a.format)
        elif a.cmd == "portrait-import":
            import_portrait(a.input, a.out)
        elif a.cmd == "set-export":
            export_set(a.bank, a.portrait, a.outdir, a.format)
        elif a.cmd == "set-import":
            import_set(a.indir, a.bankout, a.portraitout, a.format)
        elif a.cmd == "set-verify":
            verify_set(a.bank, a.portrait, a.workdir)
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        raise SystemExit(2)

if __name__ == "__main__":
    main()
