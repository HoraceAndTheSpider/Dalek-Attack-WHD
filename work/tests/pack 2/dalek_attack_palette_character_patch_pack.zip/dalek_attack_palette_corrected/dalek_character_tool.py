#!/usr/bin/env python3
"""Dalek Attack (Amiga) playable-character round-trip graphics tool.

Confirmed character graphics formats:

Animation bank
  45 frames x 32x40 pixels x 4 bitplanes
  640 bytes/frame, 28,800 bytes/bank ($7080)

Selection portrait
  1 image x 32x32 pixels x 4 bitplanes
  512 bytes ($0200)

Both use the same row/plane layout:
  for each scanline: plane0 bytes, plane1 bytes, plane2 bytes, plane3 bytes

Commands:
  export BANK.bin OUTDIR [--format png|ilbm|both]
  import INDIR OUT.bin [--format auto|png|ilbm]
  sheet BANK.bin OUT.png [--scale 4]
  verify BANK.bin WORKDIR

  portrait-export PORTRAIT.bin OUTBASE [--format png|ilbm|both]
  portrait-import INPUT OUT.bin [--format auto|png|ilbm]
  set-export BANK.bin PORTRAIT.bin OUTDIR [--format png|ilbm|both]
  set-import INDIR BANK.bin PORTRAIT.bin [--format auto|png|ilbm]
  set-verify BANK.bin PORTRAIT.bin WORKDIR

PNG output is indexed. Palette index 0 is transparent and original indices 0..15
are preserved. RGB/RGBA input is accepted only when every non-transparent pixel
exactly matches the game palette, preventing silent nearest-colour remapping.

ILBM output is standard uncompressed 4-plane ILBM with transparent colour 0.
For widths of 32 pixels the ILBM BODY byte order is exactly the game's raw byte
order. Import accepts uncompressed and ByteRun1-compressed ILBM BODY data.
"""
from __future__ import annotations
import argparse, hashlib, struct, sys
from pathlib import Path
from PIL import Image, ImageDraw

WIDTH=32
HEIGHT=40
FRAMES=45
PLANES=4
ROW_BYTES=WIDTH//8
FRAME_BYTES=ROW_BYTES*PLANES*HEIGHT
BANK_BYTES=FRAME_BYTES*FRAMES
PORTRAIT_WIDTH=32
PORTRAIT_HEIGHT=32
PORTRAIT_BYTES=(PORTRAIT_WIDTH//8)*PLANES*PORTRAIT_HEIGHT

# Main gameplay/playfield palette recovered from executable runtime $11E74.
# COLOR00 is black; the game table supplies COLOR01..COLOR15.
AMIGA12_PLAYFIELD=[
    0x000, 0x039, 0x666, 0x888, 0x642, 0x864, 0xA86, 0x264,
    0xCA4, 0x26C, 0x112, 0x488, 0x444, 0xA22, 0x000, 0xEEE,
]
# Lower/HUD palette from runtime $11E92 (full COLOR00..COLOR15 table).
AMIGA12_HUD=[
    0x000, 0x029, 0x666, 0x999, 0x642, 0x964, 0xB96, 0x264,
    0xFD4, 0xBBB, 0x224, 0x499, 0x444, 0xD22, 0x000, 0xDDF,
]

def amiga12_rgb(c:int):
    return (((c>>8)&0xF)*17, ((c>>4)&0xF)*17, (c&0xF)*17)

PLAYFIELD_RGB=[amiga12_rgb(c) for c in AMIGA12_PLAYFIELD]
HUD_RGB=[amiga12_rgb(c) for c in AMIGA12_HUD]

def pil_palette(rgb=PLAYFIELD_RGB):
    flat=[]
    for c in rgb: flat.extend(c)
    return flat+[0]*(768-len(flat))
PAL_FLAT=pil_palette()

def planar_bytes(width:int,height:int)->int:
    if width % 16:
        raise ValueError('ILBM/game width must be a multiple of 16')
    return (width//8)*PLANES*height

def decode_planar(raw:bytes,width:int,height:int)->Image.Image:
    row_bytes=width//8
    expected=row_bytes*PLANES*height
    if len(raw)!=expected:
        raise ValueError(f'planar image must be {expected} bytes, got {len(raw)}')
    im=Image.new('P',(width,height),0)
    im.putpalette(PAL_FLAT)
    px=im.load(); off=0
    for y in range(height):
        planes=[raw[off+p*row_bytes:off+(p+1)*row_bytes] for p in range(PLANES)]
        off += row_bytes*PLANES
        for x in range(width):
            bi=x>>3; bit=7-(x&7); v=0
            for p in range(PLANES):
                v |= ((planes[p][bi]>>bit)&1)<<p
            px[x,y]=v
    im.info['transparency']=0
    return im

def encode_indices(indices:list[int],width:int,height:int)->bytes:
    if len(indices)!=width*height: raise ValueError('wrong pixel count')
    row_bytes=width//8
    out=bytearray()
    for y in range(height):
        row=indices[y*width:(y+1)*width]
        for p in range(PLANES):
            for xb in range(row_bytes):
                v=0
                for bitpos in range(8):
                    x=xb*8+bitpos
                    v |= ((row[x]>>p)&1) << (7-bitpos)
                out.append(v)
    return bytes(out)

def image_to_indices(im:Image.Image,width:int,height:int)->list[int]:
    if im.size!=(width,height):
        raise ValueError(f'image must be {width}x{height}, got {im.size}')
    if im.mode=='P':
        vals=list(im.getdata())
        if any(v>15 for v in vals): raise ValueError('indexed image contains palette index >15')
        p=im.getpalette()
        if p and p[:48] != PAL_FLAT[:48]:
            raise ValueError('indexed image palette differs from Dalek Attack playfield palette; refusing ambiguous remap')
        return vals
    rgba=im.convert('RGBA')
    # Duplicate RGB entries exist (indices 0 and 14 are both black). Prefer
    # the lowest index so RGB conversion cannot silently manufacture index 14.
    cmap={}
    for i,rgb in reversed(list(enumerate(PLAYFIELD_RGB))): cmap[(*rgb,255)]=i
    vals=[]
    for px in rgba.getdata():
        if px[3]==0:
            vals.append(0); continue
        key=(px[0],px[1],px[2],255)
        if key not in cmap:
            raise ValueError(f'RGB colour {px[:3]} is not an exact game-palette colour')
        vals.append(cmap[key])
    return vals

def _chunk(tag:bytes,data:bytes)->bytes:
    return tag+struct.pack('>I',len(data))+data+(b'\0' if len(data)&1 else b'')

def write_ilbm(raw:bytes,path:Path,width:int,height:int):
    expected=planar_bytes(width,height)
    if len(raw)!=expected: raise ValueError(f'bad planar size: expected {expected}')
    bmhd=struct.pack('>HHhhBBBBHBBhh',width,height,0,0,PLANES,2,0,0,0,10,11,width,height)
    cmap=bytes([v for rgb in PLAYFIELD_RGB for v in rgb])
    payload=b'ILBM'+_chunk(b'BMHD',bmhd)+_chunk(b'CMAP',cmap)+_chunk(b'BODY',raw)
    path.write_bytes(b'FORM'+struct.pack('>I',len(payload))+payload)

def byterun1_decode(data:bytes,expected:int)->bytes:
    out=bytearray(); i=0
    while len(out)<expected:
        if i>=len(data): raise ValueError('truncated ByteRun1 BODY')
        n=struct.unpack('b',data[i:i+1])[0]; i+=1
        if 0<=n<=127:
            count=n+1
            if i+count>len(data): raise ValueError('truncated ByteRun1 literal')
            out.extend(data[i:i+count]); i+=count
        elif -127<=n<=-1:
            count=1-n
            if i>=len(data): raise ValueError('truncated ByteRun1 repeat')
            out.extend(data[i:i+1]*count); i+=1
        else:
            pass
    if len(out)!=expected: raise ValueError('ByteRun1 overrun')
    return bytes(out)

def read_ilbm(path:Path,width:int,height:int)->bytes:
    b=path.read_bytes()
    if len(b)<12 or b[:4]!=b'FORM' or b[8:12]!=b'ILBM': raise ValueError(f'{path}: not ILBM')
    pos=12; chunks={}; end=min(len(b),8+int.from_bytes(b[4:8],'big'))
    while pos+8<=end:
        tag=b[pos:pos+4]; n=int.from_bytes(b[pos+4:pos+8],'big'); pos+=8
        chunks[tag]=b[pos:pos+n]; pos+=n+(n&1)
    if b'BMHD' not in chunks or b'BODY' not in chunks: raise ValueError('ILBM missing BMHD/BODY')
    vals=struct.unpack('>HHhhBBBBHBBhh',chunks[b'BMHD'][:20])
    w,h,_,_,nplanes,masking,compression,_,transparent,_,_,_,_=vals
    if (w,h,nplanes)!=(width,height,PLANES):
        raise ValueError(f'ILBM must be {width}x{height}x{PLANES}, got {w}x{h}x{nplanes}')
    if masking not in (0,2): raise ValueError('ILBM mask plane not supported; use transparent-colour or no masking')
    if masking==2 and transparent!=0: raise ValueError('ILBM transparent colour must be index 0')
    rowbytes=((w+15)//16)*2
    expected=rowbytes*h*nplanes
    body=chunks[b'BODY']
    if compression==0:
        if len(body)<expected: raise ValueError('short ILBM BODY')
        body=body[:expected]
    elif compression==1:
        body=byterun1_decode(body,expected)
    else: raise ValueError(f'unsupported ILBM compression {compression}')
    # For width 32, ILBM rowbytes = game rowbytes = 4, so layout is identical.
    return body

def load_exact(path:Path,n:int,kind:str)->bytes:
    b=path.read_bytes()
    if len(b)!=n: raise ValueError(f'{kind} must be exactly {n} bytes, got {len(b)}')
    return b

def load_bank(path:Path)->bytes: return load_exact(path,BANK_BYTES,'bank')
def load_portrait(path:Path)->bytes: return load_exact(path,PORTRAIT_BYTES,'portrait')

def export_bank(bankpath:Path,outdir:Path,fmt:str):
    bank=load_bank(bankpath); outdir.mkdir(parents=True,exist_ok=True)
    for f in range(FRAMES):
        raw=bank[f*FRAME_BYTES:(f+1)*FRAME_BYTES]
        if fmt in ('png','both'):
            decode_planar(raw,WIDTH,HEIGHT).save(outdir/f'frame_{f:02d}.png',transparency=0)
        if fmt in ('ilbm','both'):
            write_ilbm(raw,outdir/f'frame_{f:02d}.iff',WIDTH,HEIGHT)
    (outdir/'FORMAT.txt').write_text(
        'Dalek Attack Amiga animation bank\n'
        '45 frames, 32x40, 4 planes, 640 bytes/frame, 28800 bytes/bank ($7080).\n'
        'Palette: gameplay/playfield palette from runtime $11E74; index 0 transparent.\n'
        'Do not reorder indexed PNG palette entries. RGB import requires exact palette colours.\n')

def import_bank(indir:Path,outpath:Path,fmt:str):
    if fmt=='auto':
        if all((indir/f'frame_{i:02d}.png').exists() for i in range(FRAMES)): fmt='png'
        elif all((indir/f'frame_{i:02d}.iff').exists() for i in range(FRAMES)): fmt='ilbm'
        else: raise ValueError('need complete frame_00..44 PNG or IFF set')
    out=bytearray()
    for i in range(FRAMES):
        if fmt=='png':
            im=Image.open(indir/f'frame_{i:02d}.png')
            out.extend(encode_indices(image_to_indices(im,WIDTH,HEIGHT),WIDTH,HEIGHT))
        else:
            out.extend(read_ilbm(indir/f'frame_{i:02d}.iff',WIDTH,HEIGHT))
    if len(out)!=BANK_BYTES: raise AssertionError(len(out))
    outpath.write_bytes(out)

def export_portrait(portraitpath:Path,outbase:Path,fmt:str):
    raw=load_portrait(portraitpath)
    outbase.parent.mkdir(parents=True,exist_ok=True)
    if fmt in ('png','both'):
        p=outbase if outbase.suffix.lower()=='.png' else outbase.with_suffix('.png')
        decode_planar(raw,PORTRAIT_WIDTH,PORTRAIT_HEIGHT).save(p,transparency=0)
    if fmt in ('ilbm','both'):
        p=outbase if outbase.suffix.lower() in ('.iff','.ilbm') else outbase.with_suffix('.iff')
        write_ilbm(raw,p,PORTRAIT_WIDTH,PORTRAIT_HEIGHT)

def import_portrait(inpath:Path,outpath:Path,fmt:str):
    if fmt=='auto':
        ext=inpath.suffix.lower(); fmt='png' if ext=='.png' else 'ilbm' if ext in ('.iff','.ilbm') else None
        if fmt is None: raise ValueError('cannot infer portrait format; use --format png or ilbm')
    if fmt=='png':
        im=Image.open(inpath)
        raw=encode_indices(image_to_indices(im,PORTRAIT_WIDTH,PORTRAIT_HEIGHT),PORTRAIT_WIDTH,PORTRAIT_HEIGHT)
    else:
        raw=read_ilbm(inpath,PORTRAIT_WIDTH,PORTRAIT_HEIGHT)
    outpath.write_bytes(raw)

def export_set(bankpath:Path,portraitpath:Path,outdir:Path,fmt:str):
    outdir.mkdir(parents=True,exist_ok=True)
    export_bank(bankpath,outdir/'frames',fmt)
    export_portrait(portraitpath,outdir/'portrait',fmt)
    (outdir/'SET_FORMAT.txt').write_text(
        'Complete Dalek Attack character edit set\n'
        'frames/: 45 x 32x40 animation frames -> $7080 raw bank\n'
        'portrait.png/.iff: 32x32 selection portrait -> $0200 raw portrait\n'
        'Total source payload if stored together: $7280 bytes.\n')

def import_set(indir:Path,bankout:Path,portraitout:Path,fmt:str):
    import_bank(indir/'frames',bankout,fmt)
    if fmt=='auto':
        pp=indir/'portrait.png'; pi=indir/'portrait.iff'
        p=pp if pp.exists() else pi
        if not p.exists(): raise ValueError('missing portrait.png or portrait.iff')
        import_portrait(p,portraitout,'auto')
    else:
        p=indir/('portrait.png' if fmt=='png' else 'portrait.iff')
        import_portrait(p,portraitout,fmt)

def make_sheet(bankpath:Path,outpath:Path,scale:int=4):
    bank=load_bank(bankpath); cols=9; rows=(FRAMES+cols-1)//cols; gap=2; labelh=10
    cw=WIDTH+gap; ch=HEIGHT+gap+labelh
    sheet=Image.new('RGB',(cols*cw+gap,rows*ch+gap),(16,16,16)); dr=ImageDraw.Draw(sheet)
    for i in range(FRAMES):
        raw=bank[i*FRAME_BYTES:(i+1)*FRAME_BYTES]
        im=decode_planar(raw,WIDTH,HEIGHT).convert('RGBA')
        bg=Image.new('RGBA',im.size,(0,0,0,255)); bg.alpha_composite(im)
        x=gap+(i%cols)*cw; y=gap+(i//cols)*ch
        sheet.paste(bg.convert('RGB'),(x,y)); dr.text((x,y+HEIGHT+1),f'{i:02d}',fill=(255,255,255))
    if scale!=1: sheet=sheet.resize((sheet.width*scale,sheet.height*scale),Image.Resampling.NEAREST)
    sheet.save(outpath)

def verify_bank(bankpath:Path,workdir:Path):
    original=load_bank(bankpath); workdir.mkdir(parents=True,exist_ok=True)
    print('bank original sha256',hashlib.sha256(original).hexdigest())
    for fmt in ('png','ilbm'):
        d=workdir/f'bank_{fmt}'; export_bank(bankpath,d,fmt)
        out=workdir/f'bank_roundtrip_{fmt}.bin'; import_bank(d,out,fmt)
        rebuilt=out.read_bytes(); print(fmt,'OK' if rebuilt==original else 'FAIL',hashlib.sha256(rebuilt).hexdigest())
        if rebuilt!=original: raise SystemExit(1)

def verify_set(bankpath:Path,portraitpath:Path,workdir:Path):
    bank=load_bank(bankpath); portrait=load_portrait(portraitpath); workdir.mkdir(parents=True,exist_ok=True)
    print('bank sha256',hashlib.sha256(bank).hexdigest())
    print('portrait sha256',hashlib.sha256(portrait).hexdigest())
    for fmt in ('png','ilbm'):
        d=workdir/f'set_{fmt}'; export_set(bankpath,portraitpath,d,fmt)
        bo=workdir/f'bank_roundtrip_{fmt}.bin'; po=workdir/f'portrait_roundtrip_{fmt}.bin'
        import_set(d,bo,po,fmt)
        bok=bo.read_bytes()==bank; pok=po.read_bytes()==portrait
        print(fmt,'bank', 'OK' if bok else 'FAIL','portrait','OK' if pok else 'FAIL')
        if not (bok and pok): raise SystemExit(1)

def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    sp=ap.add_subparsers(dest='cmd',required=True)
    p=sp.add_parser('export'); p.add_argument('bank',type=Path); p.add_argument('outdir',type=Path); p.add_argument('--format',choices=['png','ilbm','both'],default='both')
    p=sp.add_parser('import'); p.add_argument('indir',type=Path); p.add_argument('out',type=Path); p.add_argument('--format',choices=['auto','png','ilbm'],default='auto')
    p=sp.add_parser('sheet'); p.add_argument('bank',type=Path); p.add_argument('out',type=Path); p.add_argument('--scale',type=int,default=4)
    p=sp.add_parser('verify'); p.add_argument('bank',type=Path); p.add_argument('workdir',type=Path)
    p=sp.add_parser('portrait-export'); p.add_argument('portrait',type=Path); p.add_argument('outbase',type=Path); p.add_argument('--format',choices=['png','ilbm','both'],default='both')
    p=sp.add_parser('portrait-import'); p.add_argument('input',type=Path); p.add_argument('out',type=Path); p.add_argument('--format',choices=['auto','png','ilbm'],default='auto')
    p=sp.add_parser('set-export'); p.add_argument('bank',type=Path); p.add_argument('portrait',type=Path); p.add_argument('outdir',type=Path); p.add_argument('--format',choices=['png','ilbm','both'],default='both')
    p=sp.add_parser('set-import'); p.add_argument('indir',type=Path); p.add_argument('bankout',type=Path); p.add_argument('portraitout',type=Path); p.add_argument('--format',choices=['auto','png','ilbm'],default='auto')
    p=sp.add_parser('set-verify'); p.add_argument('bank',type=Path); p.add_argument('portrait',type=Path); p.add_argument('workdir',type=Path)
    a=ap.parse_args()
    try:
        if a.cmd=='export': export_bank(a.bank,a.outdir,a.format)
        elif a.cmd=='import': import_bank(a.indir,a.out,a.format)
        elif a.cmd=='sheet': make_sheet(a.bank,a.out,a.scale)
        elif a.cmd=='verify': verify_bank(a.bank,a.workdir)
        elif a.cmd=='portrait-export': export_portrait(a.portrait,a.outbase,a.format)
        elif a.cmd=='portrait-import': import_portrait(a.input,a.out,a.format)
        elif a.cmd=='set-export': export_set(a.bank,a.portrait,a.outdir,a.format)
        elif a.cmd=='set-import': import_set(a.indir,a.bankout,a.portraitout,a.format)
        elif a.cmd=='set-verify': verify_set(a.bank,a.portrait,a.workdir)
    except Exception as e:
        print(f'error: {e}',file=sys.stderr); raise SystemExit(2)
if __name__=='__main__': main()
